import React, { Component } from 'react'
import KBody from '../components/kmdaooo/KBody'
export default class KMDaoo extends Component {
    render() {
        return (
            <div>
            <KBody></KBody>
            </div>
        )
    }
}
